import React from 'react'
import LoginPage from './RegisterPage'

export const Home = () => {
  return (
    <div>
      <LoginPage />
    </div>
  )
}
